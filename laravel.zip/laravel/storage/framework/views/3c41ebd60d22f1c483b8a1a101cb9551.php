<?php $__env->startSection('content'); ?>
    <h1>Welcome to the Dashboard, <?php echo e(auth()->user()->name); ?>!</h1>

    <p>You are now logged in.</p>

    <a href="<?php echo e(route('logout')); ?>">Logout</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dhlbd/laravel/resources/views/dashboard.blade.php ENDPATH**/ ?>
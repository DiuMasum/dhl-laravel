<?php $__env->startSection('content'); ?>
<style>
    table {
        font-family: arial, sans-serif;
        width: 100%;
    }

    td,
    th {
        text-align: left;
        padding: 8px;
    }

    th {
        background-color: #dddddd;
    }

    .a-tag {
        text-decoration: none;
        color: white;
    }

    .a-tag:hover {
        color: white;
    }
</style>

<div class="container mt-3">
    <div class="d-flex justify-content-end align-items-center">
        <a href="<?php echo e(route('products.create')); ?>" class="bg-success text-white px-3 py-2 rounded a-tag">
            <i class="bi bi-plus-lg"></i>
            <span>Add New Products</span>
        </a>
    </div>

    <div class="container mt-2" style="background: rgb(247, 253, 255);">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Id</th>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Product Category</th>
                        <th>Product Subcategory</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Brand</th>
                        <th>Season</th>
                        <th>Collection</th>
                        <th>Barcode</th>
                        <th>Sku</th>
                        <th>Size Range</th>
                        <th>Fit Type</th>
                        <th>Size Chart</th>
                        <th>Material Composition</th>
                        <th>Base Price</th>
                        <th>Retail Price</th>
                        <th>Wholesale Price</th>
                        <th>Cost Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->product_code); ?></td>
                            <td><?php echo e($product->product_name); ?></td>
                            <td><?php echo e($product->product_category); ?></td>
                            <td><?php echo e($product->product_subcategory); ?></td>
                            <td><?php echo e($product->description); ?></td>
                            <td>
                                <?php if($product->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->product_name); ?>" style="width: 50px; height: auto;">
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($product->brand); ?></td>
                            <td><?php echo e($product->season); ?></td>
                            <td><?php echo e($product->collection); ?></td>
                            <td><?php echo e($product->barcode); ?></td>
                            <td><?php echo e($product->sku); ?></td>
                            <td><?php echo e($product->size_range); ?></td>
                            <td><?php echo e($product->fit_type); ?></td>
                            <td><?php echo e($product->size_chart); ?></td>
                            <td><?php echo e($product->material_composition); ?></td>
                            <td><?php echo e($product->base_price); ?></td>
                            <td><?php echo e($product->retails_price); ?></td>
                            <td><?php echo e($product->wholesale_price); ?></td>
                            <td><?php echo e($product->cost_price); ?></td>
                            <td>
                                <div class="d-flex justify-content-around align-items-center">
                                    <a href="<?php echo e(route('products.edit', $product->id)); ?>">
                                        <i class="bi bi-pencil-square bg-success text-white px-2 py-1 rounded" title="Edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="bg-danger border-0 text-white px-2 py-1 rounded" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dhlbd/laravel/resources/views/products/index.blade.php ENDPATH**/ ?>
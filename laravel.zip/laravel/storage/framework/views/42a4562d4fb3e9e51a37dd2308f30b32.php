<?php $__env->startSection('content'); ?>
    <style>
        table {
            font-family: arial, sans-serif;
            width: 100%;
        }

        td,
        th {
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #dddddd;
        }

        .a-tag{
            text-decoration: none;
            color: white;
        }

        .a-tag:hover {
            color: white;
        }
    </style>

    <div class="mt-3">
        <div class="d-flex justify-content-end align-items-center">
            <a href="<?php echo e(route('buyers.create')); ?>" class="bg-success text-white px-3 py-2 rounded a-tag">
                <i class="bi bi-plus-lg"></i>
                <span>Create Buyer</span>
            </a>
        </div>

        <div class="mt-2" style="background: rgb(247, 253, 255)">
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Company</th>
                        <th>Building</th>
                        <th>Street</th>
                        <th>Suburb</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Postcode</th>
                        <th>Country</th>
                        <th>Instructions</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($buyer->id); ?></td>
                            <td><?php echo e($buyer->name); ?></td>
                            <td><?php echo e($buyer->email); ?></td>
                            <td><?php echo e($buyer->phone); ?></td>
                            <td><?php echo e($buyer->company); ?></td>
                            <td><?php echo e($buyer->building); ?></td>
                            <td><?php echo e($buyer->street); ?></td>
                            <td><?php echo e($buyer->suburb); ?></td>
                            <td><?php echo e($buyer->city); ?></td>
                            <td><?php echo e($buyer->state); ?></td>
                            <td><?php echo e($buyer->postcode); ?></td>
                            <td><?php echo e($buyer->country); ?></td>
                            <td><?php echo e($buyer->instructions); ?></td>
                            <td>
                                <div class="col-6 col-md-6 col-lg-1 text-center">
                                    <div class="d-flex justify-content-around align-items-center h-100 gap-1">
                                        <a href="<?php echo e(route('buyers.edit', $buyer->id)); ?>">
                                            <i class="bi bi-pencil-square bg-success text-white px-2 py-1 rounded" title="Edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('buyers.destroy', $buyer->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="bi bi-trash bg-danger text-white px-2 py-1 rounded" title="Delete" onclick="return confirm('Are you sure you want to delete this buyer?');"></button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dhlbd/laravel/resources/views/buyers/index.blade.php ENDPATH**/ ?>